package com.safeanchor;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.*;

/**
 * Dò căn cứ (chạy mọi server: chỉ đọc chunk mà server đã gửi, vẽ khung xuyên tường):
 * Sus ESP (block người đặt dưới lòng đất), Spawner ESP, Lightfinder (nguồn sáng lạ), Hole ESP (hố an toàn).
 * Mỗi module có Min/Max Y, tầm, độ mờ, màu, bộ lọc loại block trong Cài đặt module.
 * Lưu ý: server bật anti-xray có thể giấu bớt block, và công trình tự nhiên (ancient city, mineshaft...) cũng có thể hiện lên.
 */
public class BaseScan {
    public record Hit(BlockPos pos, String cat) {}
    record Draw(Box b, int rgb, int a) {}

    static final class Chan {
        final Map<Long, List<Hit>> cache = new HashMap<>();
        final Map<Long, Integer> last = new HashMap<>();
        int sig, round;
    }
    static final Chan SUS = new Chan(), SPAWN = new Chan(), LIGHT = new Chan();
    static final Map<Block, String> susMap = new HashMap<>();
    static final Map<Block, Boolean> lightOk = new HashMap<>();
    static final List<Hit> holes = new ArrayList<>();
    static int tickN, holeCd;

    // ---------- phân loại block ----------
    static String classifySus(String id) {
        if (id.equals("smooth_basalt") || id.contains("_ore") || id.equals("infested_deepslate") || id.equals("reinforced_deepslate")) return "";
        if (id.contains("chest") || id.equals("barrel") || id.contains("shulker_box")) return "storage";
        if (id.contains("deepslate") && !id.equals("deepslate")) return "deepslate";
        if (id.contains("cobblestone")) return "cobble";
        if (id.contains("planks") || id.contains("fence") || id.contains("door") || id.contains("_sign") || id.contains("bookshelf")) return "planks";
        if (id.contains("glass")) return "glass";
        if (id.contains("rail")) return "rails";
        if (id.equals("obsidian") || id.equals("crying_obsidian") || id.equals("respawn_anchor") || id.equals("netherite_block")) return "obsidian";
        if (id.contains("redstone") || id.contains("piston") || id.equals("observer") || id.equals("repeater") || id.equals("comparator")
                || id.equals("dispenser") || id.equals("dropper") || id.equals("hopper") || id.equals("tnt")) return "redstone";
        if (id.contains("furnace") || id.equals("smoker") || id.equals("crafting_table") || id.contains("anvil") || id.equals("enchanting_table")
                || id.equals("brewing_stand") || id.endsWith("_bed") || id.equals("beacon") || id.equals("grindstone") || id.equals("loom")) return "utility";
        if (id.contains("bricks") || id.contains("concrete") || id.startsWith("polished_") || id.startsWith("smooth_") || id.startsWith("chiseled_")) return "bricks";
        return "";
    }

    static String susCat(Block b) {
        String c = susMap.get(b);
        if (c == null) { c = classifySus(Registries.BLOCK.getId(b).getPath()); susMap.put(b, c); }
        return c.isEmpty() ? null : c;
    }

    static boolean lightBlock(Block b) {
        Boolean ok = lightOk.get(b);
        if (ok == null) {
            String id = Registries.BLOCK.getId(b).getPath();
            ok = !(id.equals("lava") || id.contains("fire") || id.contains("magma") || id.contains("lichen") || id.contains("vines")
                    || id.contains("amethyst") || id.contains("_ore") || id.contains("sculk") || id.contains("portal") || id.contains("sea_pickle")
                    || id.equals("conduit") || id.equals("light") || id.contains("spawner") || id.equals("vault"));
            lightOk.put(b, ok);
        }
        return ok;
    }

    /** mode 0 = sus, 1 = spawner, 2 = light */
    static String classify(int mode, BlockState st) {
        Block b = st.getBlock();
        return switch (mode) {
            case 0 -> susCat(b);
            case 1 -> (b == Blocks.SPAWNER || b == Blocks.TRIAL_SPAWNER) ? "spawner" : null;
            default -> (st.getLuminance() >= 6 && lightBlock(b)) ? "light" : null;
        };
    }

    // ---------- quét chunk (mỗi tick 1 chunk / module) ----------
    static void scan(MinecraftClient mc, Chan ch, Mods.Cfg g, int mode) {
        int s = Objects.hash(g.minY, g.maxY);
        if (s != ch.sig) { ch.sig = s; ch.cache.clear(); ch.last.clear(); }
        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
        int rad = (int) Math.ceil(Math.max(16, g.range) / 16.0), side = rad * 2 + 1;
        for (int tries = 0; tries < side * side; tries++) {
            ch.round = (ch.round + 1) % (side * side);
            int cx = pcx - rad + ch.round % side, cz = pcz - rad + ch.round / side;
            long key = ChunkPos.toLong(cx, cz);
            Integer last = ch.last.get(key);
            if (last != null && tickN - last < 200) continue;
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cx, cz);
            if (wc == null) { ch.cache.remove(key); continue; }
            ch.last.put(key, tickN);
            List<Hit> list = new ArrayList<>();
            ChunkSection[] secs = wc.getSectionArray();
            for (int i = 0; i < secs.length && list.size() < 800; i++) {
                ChunkSection sec = secs[i];
                int baseY = (wc.getBottomSectionCoord() + i) << 4;
                if (sec.isEmpty() || baseY + 15 < g.minY || baseY > g.maxY) continue;
                if (!sec.hasAny(st -> classify(mode, st) != null)) continue;
                for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) {
                    int wy = baseY + y;
                    if (wy < g.minY || wy > g.maxY) continue;
                    String cat = classify(mode, sec.getBlockState(x, y, z));
                    if (cat != null) list.add(new Hit(new BlockPos((cx << 4) + x, wy, (cz << 4) + z), cat));
                }
            }
            ch.cache.put(key, list);
            break;
        }
    }

    // ---------- Hole ESP ----------
    static boolean safeBlock(BlockState s) {
        return s.isOf(Blocks.BEDROCK) || s.isOf(Blocks.OBSIDIAN) || s.isOf(Blocks.CRYING_OBSIDIAN) || s.isOf(Blocks.NETHERITE_BLOCK)
                || s.isOf(Blocks.RESPAWN_ANCHOR) || s.isOf(Blocks.ENDER_CHEST) || s.isOf(Blocks.REINFORCED_DEEPSLATE);
    }

    static void holes(MinecraftClient mc, Mods.Cfg g) {
        if (holeCd-- > 0) return;
        holeCd = 8;
        var w = mc.world;
        List<Hit> out = new ArrayList<>();
        int r = Math.max(3, Math.min(16, g.range)), vy = Math.min(r, 6);
        BlockPos pc = mc.player.getBlockPos();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -r; dx <= r && out.size() < 400; dx++) for (int dy = -vy; dy <= vy; dy++) for (int dz = -r; dz <= r; dz++) {
            int y = pc.getY() + dy;
            if (y < g.minY || y > g.maxY) continue;
            m.set(pc.getX() + dx, y, pc.getZ() + dz);
            if (!w.getBlockState(m).isAir() || !w.getBlockState(m.up()).isAir()) continue;
            BlockPos here = m.toImmutable();
            BlockState[] around = {w.getBlockState(here.down()), w.getBlockState(here.north()), w.getBlockState(here.south()),
                    w.getBlockState(here.east()), w.getBlockState(here.west())};
            boolean ok = true, safe = true;
            BlockPos[] ps = {here.down(), here.north(), here.south(), here.east(), here.west()};
            for (int i = 0; i < 5; i++) {
                if (!around[i].isFullCube(w, ps[i])) { ok = false; break; }
                if (!safeBlock(around[i])) safe = false;
            }
            if (ok) out.add(new Hit(here, safe ? "safe" : "unsafe"));
        }
        holes.clear(); holes.addAll(out);
    }

    // ---------- tick ----------
    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        if (mc.player == null || mc.world == null || !c.enabled) return;
        tickN++;
        if (c.susBase) scan(mc, SUS, Mods.cfg("sus"), 0); else if (!SUS.cache.isEmpty()) { SUS.cache.clear(); SUS.last.clear(); }
        if (c.spawnerEsp) scan(mc, SPAWN, Mods.cfg("spawner"), 1); else if (!SPAWN.cache.isEmpty()) { SPAWN.cache.clear(); SPAWN.last.clear(); }
        if (c.lightEsp) scan(mc, LIGHT, Mods.cfg("light"), 2); else if (!LIGHT.cache.isEmpty()) { LIGHT.cache.clear(); LIGHT.last.clear(); }
        if (c.holeEsp) holes(mc, Mods.cfg("hole")); else if (!holes.isEmpty()) holes.clear();
    }

    // ---------- vẽ ----------
    static void collect(List<Draw> out, Chan ch, Mods.Cfg g, Vec3d pp) {
        double r2 = (double) g.range * g.range;
        for (List<Hit> list : ch.cache.values()) for (Hit h : list) {
            if (g.off.contains(h.cat())) continue;
            if (Vec3d.ofCenter(h.pos()).squaredDistanceTo(pp) > r2) continue;
            out.add(new Draw(new Box(h.pos()), g.color, g.alpha));
            if (out.size() > 3000) return;
        }
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config c = Config.I;
        if (!c.enabled || mc.player == null || mc.world == null) return;
        if (!(c.susBase || c.spawnerEsp || c.lightEsp || c.holeEsp)) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;
        Vec3d cp = ctx.camera().getPos(), pp = mc.player.getPos();
        List<Draw> list = new ArrayList<>();
        if (c.susBase) collect(list, SUS, Mods.cfg("sus"), pp);
        if (c.spawnerEsp) collect(list, SPAWN, Mods.cfg("spawner"), pp);
        if (c.lightEsp) collect(list, LIGHT, Mods.cfg("light"), pp);
        if (c.holeEsp) {
            Mods.Cfg g = Mods.cfg("hole");
            for (Hit h : holes) {
                BlockPos p = h.pos();
                list.add(new Draw(new Box(p.getX() + 0.05, p.getY(), p.getZ() + 0.05, p.getX() + 0.95, p.getY() + 0.06, p.getZ() + 0.95),
                        h.cat().equals("safe") ? g.color : g.color2, g.alpha));
            }
        }
        if (list.isEmpty()) return;

        Matrix4f m = ms.peek().getPositionMatrix();
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (Draw d : list) Esp.fill(bb, m, d.b().offset(-cp.x, -cp.y, -cp.z), d.rgb(), d.a());
        BufferRenderer.drawWithGlobalProgram(bb.end());

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.lineWidth(2f);
        BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (Draw d : list) Esp.outline(lb, m, d.b().offset(-cp.x, -cp.y, -cp.z), d.rgb());
        BufferRenderer.drawWithGlobalProgram(lb.end());
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }
}
